public interface AbstractFindPathInputReader {
    char[][] readMaze();
}

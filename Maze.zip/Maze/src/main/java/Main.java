import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Welcome to maze solver.\nPlease choose input method: print 1 below to use input from keyboard or print 2 to use input from file.");
        AbstractFindPathInputReader reader;
        Scanner sc = new Scanner(System.in);
        System.out.print("-> ");
        int inVariant = sc.nextInt();

        if (inVariant == 1) {
            reader = new FindPathInputReaderStdIn();
        } else if (inVariant == 2) {
            reader = new FindPathInputReaderFile();
        } else {
            throw new IllegalArgumentException("Only 1 or 2 accepted");
        }

        MazeField field = new MazeField(reader.readMaze());
        field.printCurrentMaze();
        new Solver(field);
    }
}

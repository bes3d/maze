public class Position {

    private final Point PT;
    private final int DIST;
    private final Position PARENT;

    public Position(Point pt, int dist) {
        this.PT = pt;
        this.DIST = dist;
        this.PARENT = null;
    }

    public Position(Point pt, int dist, Position parent) {
        this.PT = pt;
        this.DIST = dist;
        this.PARENT = parent;
    }


    public Point getPt() {
        return PT;
    }

    public int getDist() {
        return DIST;
    }

    public Position getPARENT() {
        return PARENT;
    }
}

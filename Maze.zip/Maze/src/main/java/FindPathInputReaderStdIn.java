import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class FindPathInputReaderStdIn implements AbstractFindPathInputReader {

    @Override
    public char[][] readMaze() {
        char[][] maze;
        List<String> inputLines = new ArrayList<>();
        String endOfInput = "";

        System.out.println("Enter maze elements string or type \"end\" to close input dialog.\nTo build a maze, " +
                "you can use the symbols: '.' - free cell, '#' - blocked cell, 's' - start position marker, " +
                "'x' - target position.\nWrong characters will be corrected to free cell value, the width of the maze" +
                " will also be reduced to a general view");

        while (!endOfInput.equals("end")) {
            Scanner sc = new Scanner(System.in);
            System.out.print("-> ");
            String newMazeLine = sc.nextLine();

            if (newMazeLine.equalsIgnoreCase("end")) {
                endOfInput = newMazeLine;
            } else {
                inputLines.add(newMazeLine);
            }
        }

        MazeCorrector.mazeErrorsCorrector(inputLines);
        maze = new char[inputLines.size()][inputLines.get(0).length()];

        for (int i = 0; i < inputLines.size(); i++) {
            for (int j = 0; j < inputLines.get(i).length(); j++) {
                maze[i][j] = inputLines.get(i).charAt(j);
            }
        }

        return maze;
    }

}

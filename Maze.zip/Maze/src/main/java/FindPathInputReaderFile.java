import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class FindPathInputReaderFile implements AbstractFindPathInputReader {

    @Override
    public char[][] readMaze() {
        String inputData;
        char[][] maze;
        InputStreamReader fr;
        BufferedReader br;
        File file;
        String line;
        List<String> mazeStrings = new ArrayList<>();

        System.out.println("Enter filename with maze elements below.\nTo build a maze the file must contain " +
                "only these symbols: '.' - free cell, '#' - blocked cell, 's' - start position marker, " +
                "'x' - target position.\nWrong characters will be corrected to free cell value, the width of the maze" +
                " will also be reduced to a general view");
        Scanner sc = new Scanner(System.in);
        System.out.print("Input filename: ");
        inputData = sc.nextLine();

        try {
            file = new File(inputData);
            if (!file.exists() || file.isDirectory()) {
                throw new FileNotFoundException();
            }

            fr = new InputStreamReader(new FileInputStream(file), "UTF8");
            br = new BufferedReader(fr);

            while ((line = br.readLine()) != null) {
                mazeStrings.add(line);
            }
        } catch (FileNotFoundException fnfe) {
            System.out.println("The file " + inputData + " does not exist");
            fnfe.printStackTrace();
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }

        MazeCorrector.mazeErrorsCorrector(mazeStrings);
        maze = new char[mazeStrings.size()][mazeStrings.get(0).length()];

        for (int i = 0; i < mazeStrings.size(); i++) {
            for (int j = 0; j < mazeStrings.get(i).length(); j++) {
                maze[i][j] = mazeStrings.get(i).charAt(j);
            }
        }

        return maze;
    }
}



import java.util.List;

public class MazeCorrector {
    public static void mazeErrorsCorrector(List<String> mazeForCorrection) {
        System.out.println("Checking maze for wrong values...");
        int fieldMaxWidth = 0;
        String strForCorrection;
        boolean startPosAvailability = false;
        boolean endPosAvailability = false;
        int[] coordinates;

        //size correction
        for (String s : mazeForCorrection) {
            if (s.length() > fieldMaxWidth) {
                fieldMaxWidth = s.length();
            }
        }
        for (int i = 0; i < mazeForCorrection.size(); i++) {
            String curLine = mazeForCorrection.get(i);
            if (curLine.length() < fieldMaxWidth) {
                for (int j = curLine.length(); j < fieldMaxWidth; j++) {
                    curLine = curLine.concat(".");
                }
                mazeForCorrection.set(i, curLine);
            }
        }

        //cell value correction
        for (int i = 0; i < mazeForCorrection.size(); i++) {
            for (int j = 0; j < mazeForCorrection.get(i).length(); j++) {
                strForCorrection = mazeForCorrection.get(i);
                char checkedChar = Character.toLowerCase(strForCorrection.charAt(j));
                if (checkedChar != '.' && checkedChar != 's' && checkedChar != 'x' && checkedChar != '#') {
                    strForCorrection = replaceCharInStr(strForCorrection, '.', j);
                    mazeForCorrection.set(i, strForCorrection);
                } else if (checkedChar == 's' && startPosAvailability) {
                    strForCorrection = replaceCharInStr(strForCorrection, '.', j);
                    mazeForCorrection.set(i, strForCorrection);
                } else if (checkedChar == 'x' && endPosAvailability) {
                    strForCorrection = replaceCharInStr(strForCorrection, '.', j);
                    mazeForCorrection.set(i, strForCorrection);
                }

                if (checkedChar == 's') {
                    startPosAvailability = true;
                } else if (checkedChar == 'x') {
                    endPosAvailability = true;
                }
            }
        }

        //generate start-end pos if not set
        coordinates = getRandomCellNumber(mazeForCorrection);
        String editedStr;
        if (!startPosAvailability) {
            editedStr = replaceCharInStr(mazeForCorrection.get(coordinates[0]),'s', coordinates[1]);
            mazeForCorrection.set(coordinates[0], editedStr);
        }
        if (!endPosAvailability) {
            int[] tempCoordinates = getRandomCellNumber(mazeForCorrection);
            while (coordinates[0] == tempCoordinates[0] && coordinates[1] == tempCoordinates[1]) {
                tempCoordinates = getRandomCellNumber(mazeForCorrection);
            }
            editedStr = replaceCharInStr(mazeForCorrection.get(coordinates[0]),'x', coordinates[1]);
            mazeForCorrection.set(coordinates[0], editedStr);
        }

    }

    private static int[] getRandomCellNumber(List<String> maze) {
        int maxHeight = maze.size() - 1;
        int maxWidth = maze.get(0).length() - 1;

        int height = (int) (Math.random() * maxHeight);
        int width = (int) (Math.random() * maxWidth);

        return new int[]{height, width};
    }

    private static String replaceCharInStr(String strForEdit, char symbol, int position){
        StringBuilder resultString = new StringBuilder(strForEdit);
        resultString.setCharAt(position, symbol);

        return resultString.toString();
    }

}

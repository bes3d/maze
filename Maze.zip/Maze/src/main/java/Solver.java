import java.util.*;

class Solver {
    private final MazeField FIELD;

    public Solver(MazeField field) {
        this.FIELD = field;
        field.printPath(findWay());
    }

    private List<Position> findWay() {
        Point startPoint = FIELD.getStartPoint();
        Point endPoint = FIELD.getEndPoint();
        int[] xCoords = {-1, 0, 0, 1};
        int[] yCoords = {0, -1, 1, 0};

        boolean[][] visited = new boolean[FIELD.getRow()][FIELD.getCol()];
        visited[startPoint.getX()][startPoint.getY()] = true;

        Queue<Position> movesQueue = new LinkedList<>();
        Position srcPosition = new Position(FIELD.getStartPoint(), 0);
        movesQueue.add(srcPosition);

        while (!movesQueue.isEmpty()) {
            Position curr = movesQueue.peek();
            Point pt = curr.getPt();

            if (pt.getX() == endPoint.getX() && pt.getY() == endPoint.getY()) {
                return traceRoute(curr);
            }

            movesQueue.remove();
            for (int i = 0; i < 4; i++) {
                int row = pt.getX() + xCoords[i];
                int col = pt.getY() + yCoords[i];

                if (isValid(row, col) && !visited[row][col]) {
                    visited[row][col] = true;
                    Position nextCell = new Position(new Point(row, col), curr.getDist() + 1, curr);
                    movesQueue.add(nextCell);
                }
            }
        }

        return Collections.emptyList();
    }

    private boolean isValid(int row, int col) {
        return (row >= 0) && (row < FIELD.getRow()) && (col >= 0) && (col < FIELD.getCol())
                && (FIELD.getFullField()[row][col] != '#');
    }

    private List<Position> traceRoute(Position curr) {
        List<Position> path = new ArrayList<>();
        Position iter = curr;

        while (iter != null) {
            path.add(iter);
            iter = iter.getPARENT();
        }

        return path;
    }


}



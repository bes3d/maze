import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MazeField {
    private final char[][] FULL_FIELD;
    private final int ROW;
    private final int COL;
    private Point startPoint;
    private Point endPoint;

    public MazeField(char[][] fieldFromInput) {
        FULL_FIELD = fieldFromInput;
        ROW = fieldFromInput.length;
        COL = fieldFromInput[0].length;

        for (int i = 0; i < fieldFromInput.length; i++) {
            for (int j = 0; j < fieldFromInput[i].length; j++) {
                if (Character.toLowerCase(fieldFromInput[i][j]) == 's') {
                    startPoint = new Point(i, j);
                } else if (Character.toLowerCase(fieldFromInput[i][j]) == 'x') {
                    endPoint = new Point(i, j);
                }
            }
        }
    }

    public int getRow() {
        return ROW;
    }

    public int getCol() {
        return COL;
    }

    public Point getStartPoint() {
        return startPoint;
    }

    public Point getEndPoint() {
        return endPoint;
    }

    public char[][] getFullField() {
        return FULL_FIELD;
    }

    private boolean isStart(int x, int y) {
        return x == startPoint.getX() && y == startPoint.getY();
    }

    private boolean isExit(int x, int y) {
        return x == endPoint.getX() && y == endPoint.getY();
    }

    public void printPath(List<Position> path) {
        Point parentPoint = startPoint;
        Point childPoint;
        List<Character> revDirections = new ArrayList<>();
        int diffX;
        int diffY;

        char[][] solvedMaze = Arrays.stream(FULL_FIELD)
                .map(char[]::clone)
                .toArray(char[][]::new);

        for (Position pos : path) {
            childPoint = new Point(pos.getPt().getX(), pos.getPt().getY());
            diffX = childPoint.getX() - parentPoint.getX();
            diffY = childPoint.getY() - parentPoint.getY();
            if (diffX == 1 && diffY == 0) {
                revDirections.add('u');
            } else if (diffX == -1 && diffY == 0) {
                revDirections.add('d');
            } else if (diffX == 0 && diffY == 1) {
                revDirections.add('l');
            } else if (diffX == 0 && diffY == -1) {
                revDirections.add('r');
            }

            if (isStart(pos.getPt().getX(), pos.getPt().getY()) || isExit(pos.getPt().getX(), pos.getPt().getY())) {
                continue;
            }

            parentPoint = childPoint;
            solvedMaze[pos.getPt().getX()][pos.getPt().getY()] = '*';
        }

        System.out.println("++++++++++++++++++++++++++++++++++++++++++\nFound solution:");
        if (path.isEmpty()) {
            System.out.println("Solution not found");
        } else {
            for (char[] chars : solvedMaze) {
                for (char aChar : chars) {
                    System.out.print(aChar);
                }
                System.out.println();
            }
        }

        List<Character> directions = new ArrayList<>();
        for (int i = revDirections.size() - 1; i >= 0; i--) {
            directions.add(revDirections.get(i));
        }
        directions.add(directions.get(directions.size() - 1));

        System.out.println("The shortest path consists of " + path.get(0).getDist() + " steps");

        System.out.println("Used directions:");
        System.out.println(directions);
    }

    public void printCurrentMaze(){
        for (char[] chars : FULL_FIELD) {
            for (char aChar : chars) {
                System.out.print(aChar);
            }
            System.out.println();
        }
    }

}
